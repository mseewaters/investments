### Application
streamlit run retirement.py

### references
historical rates: https://pages.stern.nyu.edu/~adamodar/New_Home_Page/datafile/histretSP.html
